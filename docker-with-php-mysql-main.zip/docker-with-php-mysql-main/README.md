# [Stop using XAMPP: A Step-by-Step Guide to Docker for PHP and MySQL](https://medium.com/@madhurajayashanka/stop-using-xampp-a-step-by-step-guide-to-docker-for-php-and-mysql-b424f0a7ba41)


Welcome to the repository for the article "Elevate Your Web Development: Migrating from XAMPP to Docker for PHP and MySQL." In this guide, you'll learn how to modernize your web development workflow by switching from XAMPP to Docker for PHP and MySQL.

## References

- [Medium Article](https://medium.com/@madhurajayashanka/stop-using-xampp-a-step-by-step-guide-to-docker-for-php-and-mysql-b424f0a7ba41)
